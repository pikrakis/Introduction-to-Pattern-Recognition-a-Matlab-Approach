% "Introduction to Pattern Recognition: A MATLAB Approach"
% S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
%
% CHAPTER 4: book examples
%
%   example421 - Example 4.2.1
%   example431 - Example 4.3.1
%   example441 - Example 4.4.1
%   example451 - Example 4.5.1
%   example461 - Example 4.6.1
%   example462 - Example 4.6.2
%   example471 - Example 4.7.1
%   example472 - Example 4.7.2
%   example473 - Example 4.7.3
%   example481 - Example 4.8.1
%   example482 - Example 4.8.2
%   example483 - Example 4.8.3
%   example484 - Example 4.8.4
